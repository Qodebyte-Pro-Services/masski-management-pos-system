const CACHE_NAME = 'pos-cache-v1';

const urlsToCache = [
  '/', // If served from root
  '/pos.html', // adjust if your file is in a subfolder
  '/json/products.json',
  '/json/category.json',
  '/json/brand.json',

  // Assets from your local folders (relative to where the service worker is served)
  '/assets/images/favicon.svg',
  '/assets/images/gas1.png', // include any other images you're using
  '/assets/fonts/bootstrap/bootstrap-icons.css',
  '/assets/css/qode-d1.css',
  '/assets/css/main.min.css',

  // CDN files (these will work if the user loaded them once online)
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://code.jquery.com/jquery-3.7.1.min.js',
  'https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css',
  'https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/localforage/1.10.0/localforage.min.js'
];

// ✅ Install
self.addEventListener('install', event => {
  console.log('📦 Installing service worker...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(urlsToCache);
    })
  );
});

// ✅ Activate and clean up old caches
self.addEventListener('activate', event => {
  console.log('🔁 Activating new service worker...');
  event.waitUntil(
    caches.keys().then(cacheNames =>
      Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME)
          .map(name => caches.delete(name))
      )
    )
  );
});

// ✅ Fetch
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request).catch(() =>
      caches.match(event.request).then(response => {
        return response || new Response('⚠️ Resource not available offline', {
          status: 503,
          statusText: 'Offline'
        });
      })
    )
  );
});
