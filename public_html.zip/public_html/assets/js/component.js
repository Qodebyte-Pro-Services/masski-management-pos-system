
						async function includeHTML(id, path) {
						  const res = await fetch(path);
						  const html = await res.text();
						  document.getElementById(id).innerHTML = html;


             
					  
						  
   if (id === "Sidebar") {
        highlightActiveSidebarLink();
        attachLogoutHandler(); 
          checkAccess();
          LogoFetch();
          inactiveLogout()
         setTimeout(applyRolePermissions, 200);
    }
						  if (id === "header") {
                 updateAdminInfo();
                 loadNotifications();
                 updateNotificationLabel();
                 
                 const nextBtn = document.getElementById('notification-next');
    const prevBtn = document.getElementById('notification-prev');

    const closeBtn = document.getElementById('close-notification-dropdown');

     if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      const dropdown = bootstrap.Dropdown.getOrCreateInstance(document.querySelector('.header-action-icon[data-bs-toggle="dropdown"]'));
      dropdown.hide();
    });
  }

    if (nextBtn) {
      nextBtn.onclick = function () {
        notificationPage++;
        loadNotifications(notificationPage);
      };
    }
    
     if (prevBtn) {
      prevBtn.onclick = function () {
        if (notificationPage > 1) notificationPage--;
        loadNotifications(notificationPage);
      };
    }
              }; 

               if (id === "footer") {
                updateFooterCompanyName();
              }
						}

            function attachLogoutHandler() {
    const logoutBtn = document.getElementById('log-outside');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function (e) {
            e.preventDefault();
            try {
                await fetch('https://api.maskiadmin-management.com/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
            } catch (err) {
                console.error('Logout failed:', err);
                showToast('Logout failed. Please try again.', 'danger');
            }
            sessionStorage.removeItem('admin');
            window.location.href = '../account/login';
        });
    }
}
					  
						function highlightActiveSidebarLink() {
							// Normalize current path
							let currentPath = window.location.pathname
							  .replace(/\/index\.html$/, '')
							  .replace(/\/$/, '');
						  
							const navLinks = document.querySelectorAll('.sidebar-menu a');
						  
							navLinks.forEach(link => {
							  let href = link.getAttribute('href')
								.replace(/\/index\.html$/, '')
								.replace(/\/$/, '');
						  
							  // Resolve href to full path
							  const linkPath = new URL(href, window.location.origin).pathname
								.replace(/\/index\.html$/, '')
								.replace(/\/$/, '');
						  
							  // Check if current path starts with the link path
							  if (currentPath.startsWith(linkPath)) {
								navLinks.forEach(l => l.parentElement.classList.remove('active', 'current-page'));
								link.parentElement.classList.add('active', 'current-page');
							  }
							});
						  }
						  
					  
						includeHTML("footer", "../component/footer.html");
						includeHTML("Sidebar", "../component/sidebar.html");
                        includeHTML("header", "../component/header.html");
                        includeHTML("model", "../component/model.html");


function updateAdminInfo() {
	console.log('Updating admin info...');
    let admin = { first_name: '', last_name: '', role: '' };
    try {
        const adminStr = sessionStorage.getItem('admin');
        if (adminStr) {
            const parsed = JSON.parse(adminStr);
            admin.first_name = parsed.first_name || '';
            admin.last_name = parsed.last_name || '';
            admin.role = parsed.role || 'Admin';
        }
    } catch {}

    const fullNameElem = document.getElementById('full_name');
    if (fullNameElem) {
        fullNameElem.textContent = `${admin.first_name} ${admin.last_name}`.trim() || 'User';
    }

    const firstNameElem = document.getElementById('first-name');
    if (firstNameElem) {
        firstNameElem.textContent = admin.first_name || 'User';
    }

    const adminRoleElem = document.getElementById('admin-role');
    if (adminRoleElem) {
        adminRoleElem.textContent = admin.role || 'Admin';
    }

    const greetingSpan = firstNameElem?.parentElement;
    if (greetingSpan) {
        const hour = new Date().getHours();
        let greeting = 'Good Morning, ';
        if (hour >= 12 && hour < 17) {
            greeting = 'Good Afternoon, ';
        } else if (hour >= 17 || hour < 5) {
            greeting = 'Good Evening, ';
        }
        greetingSpan.childNodes[0].nodeValue = greeting;
    }
}


  	function showToast(message, type = "success") {
    let toast = document.createElement("div");
    toast.className = `toast align-items-center text-bg-${type === "success" ? "success" : "danger"} border-0 show position-fixed top-0 end-0 m-3`;
    toast.style.zIndex = 9999;
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 3500);
    toast.querySelector('.btn-close').onclick = () => toast.remove();
}


let notificationPage = 1;
const notificationLimit = 5;

async function loadNotifications() {
    let admin_id = null;
     let admin_role = null;
    try {
        const admin = JSON.parse(sessionStorage.getItem('admin'));
        admin_id = admin?.id;
         admin_role = admin?.admin_role;
    } catch {}
    if (!admin_id) return;

    try {
        const res = await fetch(`https://api.maskiadmin-management.com/admin/notifications/${admin_id}?page=${notificationPage}&limit=${notificationLimit}`);
        const data = await res.json();
        const notifications = data.notifications || [];
        const list = document.getElementById('notification-list');
        if (!list) return;

         if (admin_role !== 'super_admin' && admin_role !== 'manager' && admin_role !== 'dev') {
            notifications = notifications.filter(n => n.type === 'low_stock');
            list.innerHTML = notifications.length === 0
                ? `<div class="dropdown-item text-center text-muted">No notifications</div>`
                : notifications.map(n => renderLowStockNotificationSimple(n)).join('');
        } else {
            list.innerHTML = notifications.length === 0
                ? `<div class="dropdown-item text-center text-muted">No notifications</div>`
                : notifications.map(n => renderNotification(n)).join('');
        }

        document.getElementById('notification-prev').style.display = notificationPage > 1 ? 'block' : 'none';
        document.getElementById('notification-next').style.display = notifications.length === notificationLimit ? 'block' : 'none';
    } catch (e) {
        const list = document.getElementById('notification-list');
        if (list) list.innerHTML = `<div class="dropdown-item text-center text-danger">Failed to load notifications</div>`;
    }
}


function timeAgo(date) {
    if (!date) return '';
    const now = new Date();
    const then = new Date(date);
    const diff = Math.floor((now - then) / 1000);
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff/60)} mins ago`;
    if (diff < 86400) return `${Math.floor(diff/3600)} hours ago`;
    return `${Math.floor(diff/86400)} days ago`;
}

function renderNotification(n) {
    if (n.type === 'login_attempt') {
        if (n.status === 'pending_approval') {
            return `
            <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
              <div class="d-flex py-2 border-bottom">
                <div class="icon-box md bg-danger rounded-circle me-3">
                  <i class="bi bi-exclamation-octagon text-white fs-4"></i>
                </div>
                <div class="m-0">
                  <h6 class="mb-1 fw-semibold">New Device Detected</h6>
                  <p class="mb-2">New Device Detected IP: ${n.ip_address || '--'}</p>
                  <div class="d-flex flex-wrap gap-2">
                    <p class="mb-2">Device: ${n.device_info || n.user_agent || '--'}</p>
                    <button type="button" class="btn btn-success btn-sm" onclick="approveDevice('${n.ref_id}', true)">Approve</button>
                    <button type="button" class="btn btn-danger btn-sm" onclick="approveDevice('${n.ref_id}', false)">Block</button>
                  </div>
                  <p class="small m-0 text-secondary">${timeAgo(n.login_time)}</p>
                </div>
              </div>
            </div>`;
        }
        if (n.status === 'pending_otp') {
            return `
            <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
              <div class="d-flex py-2 border-bottom">
                <div class="icon-box md bg-danger rounded-circle me-3">
                  <i class="bi bi-exclamation-octagon text-white fs-4"></i>
                </div>
                <div class="m-0">
                  <h6 class="mb-1 fw-semibold">OTP Approval</h6>
                  <p class="mb-2">Staff ${n.email} is attempting to log in.</p>
                  <div class="d-flex flex-wrap gap-2">
                    <p class="mb-2">Send this OTP to the staff: <span class="fw-bold">${n.otp_code || '******'}</span></p>
                    <button type="button" class="btn btn-primary btn-sm" onclick="navigator.clipboard.writeText('${n.otp_code || ''}')">Copy OTP</button>
                  </div>
                  <p class="small m-0 text-secondary">${timeAgo(n.login_time)}</p>
                </div>
              </div>
            </div>`;
        }
        if (n.status === 'otp_verified') {
            return `
            <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
              <div class="d-flex py-2 border-bottom">
                <div class="icon-box md bg-success rounded-circle me-3">
                  <i class="bi bi-exclamation-triangle text-white fs-4"></i>
                </div>
                <div class="m-0">
                  <h6 class="mb-1 fw-semibold">Staff Login Detected</h6>
                  <p class="mb-1 ">${n.email} just logged in from IP: ${n.ip_address || '--'}</p>
                  <p class="small m-0 text-secondary">${timeAgo(n.login_time)}</p>
                </div>
              </div>
            </div>`;
        }
    }
    if (n.type === 'low_stock') {
        return `
        <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
          <div class="d-flex py-2 border-bottom">
            <div class="icon-box md bg-warning rounded-circle me-3">
              <i class="bi bi-exclamation-square text-white fs-4"></i>
            </div>
            <div class="m-0">
              <h6 class="mb-1 fw-semibold">Low Stock Alert</h6>
              <p class="mb-2">${n.product_name} has reached the minimum threshold.</p>
              <div class="d-flex flex-wrap gap-2">
                <p class="mb-2">Remaining: ${n.current_variations_stock_qty_number} units.</p>
                <button type="button" class="btn btn-success btn-sm">Reorder</button>
                <button type="button" class="btn btn-secondary btn-sm">View Inventory</button>
              </div>
              <p class="small m-0 text-secondary">${timeAgo(n.created_at || n.date)}</p>
            </div>
          </div>
        </div>`;
    }
    if (n.type === 'stock_modification') {
   return `
    <div class="dropdown-item w-100">
      <div class="d-flex py-2 border-bottom w-100">
        <div class="icon-box md bg-secondary rounded-circle me-3">
          <i class="bi bi-box-seam text-white fs-4"></i>
        </div>
        <div class="m-0 flex-grow-1">
          <h6 class="mb-1 fw-semibold">Stock ${n.adjustment_action === 'increase' ? 'Increase' : 'Decrease'}</h6>
          <p class="mb-2">${n.product_name} (${n.adjustment_type || ''})</p>
          <p class="mb-2">Qty: ${n.size} | By: ${n.performed_by || 'System'}</p>
          <p class="small m-0 text-secondary">${timeAgo(n.date)}</p>
        </div>
      </div>
    </div>
  `;
}
    if (n.type === 'expense_approval') {
        return `
        <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
          <div class="d-flex py-2 border-bottom">
            <div class="icon-box md bg-info rounded-circle me-3">
              <i class="bi bi-cash-coin text-white fs-4"></i>
            </div>
            <div class="m-0">
              <h6 class="mb-1 fw-semibold">Expense Approval Needed</h6>
              <p class="mb-2">${n.expense_category_name}: ₦${n.amount} - ${n.description}</p>
              <div class="d-flex flex-wrap gap-2">
              <button type="button" class="btn btn-success btn-sm" onclick="approveExpense('${n.ref_id}')">Approve</button>
              <button type="button" class="btn btn-danger btn-sm" onclick="rejectExpense('${n.ref_id}')">Reject</button>
              </div>
              <p class="small m-0 text-secondary">${timeAgo(n.date)}</p>
            </div>
          </div>
        </div>`;
    }
    if (n.type === 'staff_surcharge') {
    return `
      <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
        <div class="d-flex py-2 border-bottom">
          <div class="icon-box md bg-warning rounded-circle me-3">
            <i class="bi bi-cash-stack text-white fs-4"></i>
          </div>
          <div class="m-0">
            <h6 class="mb-1 fw-semibold">Surcharge Added</h6>
            <p class="mb-2">₦${n.amount} surcharge for ${n.full_name} $: ${n.reason}</p>
            <p class="small m-0 text-secondary">${timeAgo(n.date)}</p>
          </div>
        </div>
      </div>`;
}
if (n.type === 'staff_added') {
    return `
      <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
        <div class="d-flex py-2 border-bottom">
          <div class="icon-box md bg-success rounded-circle me-3">
            <i class="bi bi-person-plus text-white fs-4"></i>
          </div>
          <div class="m-0">
            <h6 class="mb-1 fw-semibold">New Staff Added</h6>
            <p class="mb-2">${n.full_name} (${n.email})</p>
            <p class="small m-0 text-secondary">${timeAgo(n.date)}</p>
          </div>
        </div>
      </div>`;
}
if (n.type === 'shift_change') {
    return `
      <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
        <div class="d-flex py-2 border-bottom">
          <div class="icon-box md bg-info rounded-circle me-3">
            <i class="bi bi-arrow-repeat text-white fs-4"></i>
          </div>
          <div class="m-0">
            <h6 class="mb-1 fw-semibold">Staff Shift Changed</h6>
            <p class="mb-2"> ${n.type} for ${n.fullname} Work days: ${n.work_days
} will work for ${n.working_hours}</p>
            <p class="small m-0 text-secondary">${timeAgo(n.date)}</p>
          </div>
        </div>
      </div>`;
}
    if (n.type === 'activity_log') {
        return `
        <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
          <div class="d-flex py-2 border-bottom">
            <div class="icon-box md bg-primary rounded-circle me-3">
              <i class="bi bi-info-circle text-white fs-4"></i>
            </div>
            <div class="m-0">
              <h6 class="mb-1 fw-semibold">${n.activity_type}</h6>
              <p class="mb-2">${n.description}</p>
              <p class="small m-0 text-secondary">${timeAgo(n.created_at)}</p>
            </div>
          </div>
        </div>`;
    }
    
    return '';
}


function renderLowStockNotificationSimple(n) {
    return `
    <div style="width: 100%; box-sizing:border-box" class="dropdown-item">
      <div class="d-flex py-2 border-bottom">
        <div class="icon-box md bg-warning rounded-circle me-3">
          <i class="bi bi-exclamation-square text-white fs-4"></i>
        </div>
        <div class="m-0">
          <h6 class="mb-1 fw-semibold">Low Stock Alert</h6>
          <p class="mb-2">${n.product_name} has reached the minimum threshold.</p>
          <p class="mb-2">Remaining: ${n.current_variations_stock_qty_number} units.</p>
          <p class="small m-0 text-secondary">${timeAgo(n.created_at || n.date)}</p>
        </div>
      </div>
    </div>`;
}


window.approveDevice = async function (login_attempt_id, approve) {
    try {
        const admin = JSON.parse(sessionStorage.getItem('admin'));
        const admin_id = admin?.id;
        if (!admin_id) {
            showToast('No admin in session', 'danger');
            return;
        }
        const res = await fetch(`https://api.maskiadmin-management.com/approve-device/${admin_id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ login_attempt_id, approve })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to update device approval');
        showToast(data.message, 'success');
        setTimeout(() => {
            window.location.reload();
          }, 2000);
    } catch (err) {
        showToast('Error: ' + err.message, 'danger');
    }
};

window.approveExpense = async function(id) {
    if (!id) {
        showToast('Invalid expense ID', 'danger');
        return;
    }
    if (!confirm("Approve this expense?")) return;
    try {
        const res = await fetch(`https://api.maskiadmin-management.com/expense/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                expense_status: 'approved',
                approved_by: getApprovedBy()
            })
        });
        const data = await res.json();
        if (data.message === 'Expense updated') {
            showToast('Expense approved successfully', 'success');
             setTimeout(() => {
            window.location.reload();
        }, 2000);
        } else {
            throw new Error(data.error || 'Approval failed');
        }
    } catch (error) {
        showToast('Failed to approve expense', 'danger');
    }
};

window.rejectExpense = async function(id) {
    if (!id) {
        showToast('Invalid expense ID', 'danger');
        return;
    }
    if (!confirm("Reject this expense?")) return;
    try {
        const res = await fetch(`https://api.maskiadmin-management.com/expense/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                expense_status: 'rejected',
                approved_by: getApprovedBy()
            })
        });
        const data = await res.json();
        if (data.message === 'Expense updated') {
            showToast('Expense rejected successfully', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } else {
            throw new Error(data.error || 'Rejection failed');
        }
    } catch (error) {
        showToast('Failed to reject expense', 'danger');
    }
};


function getApprovedBy() {
    try {
        const admin = JSON.parse(sessionStorage.getItem('admin'));
        return admin?.first_name + ' ' + admin?.last_name || admin?.id || 'Admin';
    } catch {
        return 'Admin';
    }
}


async function updateNotificationLabel() {
    let admin_id = null;
    try {
        const admin = JSON.parse(sessionStorage.getItem('admin'));
        admin_id = admin?.id;
    } catch {}
    if (!admin_id) return;

    try {
        const res = await fetch(`https://api.maskiadmin-management.com/admin/notifications-count/${admin_id}`);
        const data = await res.json();
        const label = document.getElementById('notification-label');
        if (label) label.textContent = data.count > 0 ? data.count : '';
    } catch (e) {
        console.error('Failed to update notification label:', e);
        const label = document.getElementById('notification-label');
        if (label) label.textContent = '';
        showToast('Failed to update notification count', 'danger');
    }
}


async function applyRolePermissions() {
  
    let admin = null;
    try {
        admin = JSON.parse(sessionStorage.getItem('admin'));
    } catch {}
    if (!admin || !admin.admin_role) return;

   
    if (admin.admin_role === 'super_admin' || admin.admin_role === 'dev') return;

    
    let roles = [];
    try {
        const res = await fetch('https://api.maskiadmin-management.com/roles');
        roles = await res.json();
    } catch {
        showToast('Failed to load roles', 'danger');
        return;
    }

   
    const adminRole = roles.find(r => r.role_name === admin.role);
    if (!adminRole) return;

    const permissions = adminRole.permissions || {};

    
    const sidebarMap = {
        Dashboard: { selector: 'a[href*="../dashboard/"]', perm: 'Dashboard_index' },
        Inventory: { selector: 'a[href*="../inventory/"]', perm: 'Inventory_index' },
        Sales: { selector: 'a[href*="../sales/"]', perm: 'Sales_index' },
        Finances: { selector: 'a[href*="../finance/"]', perm: 'Finance_index' },
        Customers: { selector: 'a[href*="../customer/"]', perm: 'Customer_index' },
        Staff: { selector: 'a[href*="../staffs/"]', perm: 'Staff_index' },
        Suppliers: { selector: 'a[href*="../supplier/"]', perm: 'Supplier_index' },
        Settings: { selector: 'a[href*="../setting/"]', perm: 'Setting_index' }
    };

    Object.values(sidebarMap).forEach(item => {
        const link = document.querySelector(item.selector);
        if (link && !permissions[item.perm]) {
            link.closest('li').style.display = 'none';
        }
    });

    
    const pagePermMap = [
       

       
        { folder: 'customer', pages: ['detail.html','index.html','invoice.html'] },
       
        { folder: 'dashboard', pages: ['index.html'] },
       
        { folder: 'finance', pages: ['budget.html','exp-detail.html','expenses.html','index.html','tax.html'] },
        
        { folder: 'inventory', pages: ['detail.html','index.html','po.html'] },
      
        { folder: 'sales', pages: ['index.html','invoice.html','pos.html','reports-details.html','reports.html','sales-reports.html'] },
      
        { folder: 'setting', pages: ['index.html'] },
      
        { folder: 'staffs', pages: ['detail.html','index.html'] },
       
        { folder: 'supplier', pages: ['detail.html','index.html','invoice.html'] }
    ];

    
    const pathParts = window.location.pathname.split('/');
    const folder = pathParts[pathParts.length - 2] || '';
    const page = pathParts[pathParts.length - 1] || '';

    
    let permKey = null;
    for (const group of pagePermMap) {
        if (group.pages.includes(page)) {
            permKey = `${group.folder}_${page.replace('.html','')}`;
            break;
        }
    }

    
    if (permKey && permissions[permKey] === false) {
        document.body.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:100vh;">
                <div class="text-center">
                    <h2>Access Denied</h2>
                    <p>You do not have permission to view this page.</p>
                </div>
            </div>
        `;
        return;
    }
}

function checkAccess() {
  const adminStr = sessionStorage.getItem('admin');
  if (!adminStr) {
    showToast('You must be logged in to access this page.', 'danger');
    window.location.href = '../account/login';
    return;
  }

  try {
    const admin = JSON.parse(adminStr);
    if (!admin.id || !admin.admin_role) {
      showToast('You must be logged in to access this page.', 'danger');
      window.location.href = '../account/login';
    }
  } catch (err) {
    console.error('Invalid admin session data');
    window.location.href = '../account/login';
  }
}

function inactiveLogout() {
    let timeout;
    const logoutAfter = 30 * 60 * 1000; 
    function doLogout() {
        try {
            const adminStr = sessionStorage.getItem('admin');
            let admin_role = '';
            if (adminStr) {
                const admin = JSON.parse(adminStr);
                admin_role = admin?.admin_role || '';
            }
            sessionStorage.clear();
            fetch('https://api.maskiadmin-management.com/logout', {
                method: 'POST',
                credentials: 'include'
            }).finally(() => {

                if (admin_role === 'super_admin' || admin_role === 'dev') {
                   sessionStorage.removeItem('admin');
                    window.location.href = '../account/login';
                } else {
                   sessionStorage.removeItem('admin');
                    window.location.href = '../staff-login';
                }
            });
        } catch {
           sessionStorage.removeItem('admin');
            window.location.href = '../staff-login';
        }
       
    }

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(doLogout, logoutAfter);
    }

   
    ['click', 'mousemove', 'keydown', 'scroll', 'touchstart'].forEach(evt => {
        document.addEventListener(evt, resetTimer, true);
    });

    resetTimer();
}


async function LogoFetch() {
    try {
       
        const adminStr = sessionStorage.getItem('admin');
        let admin_id = '1'; 
        if (adminStr) {
            try {
                const admin = JSON.parse(adminStr);
                if (admin?.id) admin_id = admin.id;
            } catch {}
        }
        const res = await fetch(`https://api.maskiadmin-management.com/owner_info/${admin_id}`);
        if (!res.ok) throw new Error('No owner info');
        const data = await res.json();
        const logoElem = document.getElementById('company-logo');
        if (!logoElem) return;
        if (data.company_logo) {
            logoElem.src = `https://api.maskiadmin-management.com/uploads/company_logo/${data.company_logo}`;
        } else {
            logoElem.src = '../assets/images/IMG_4703.PNG';
        }
    } catch {
        const logoElem = document.getElementById('company-logo');
        if (logoElem) logoElem.src = '../assets/images/IMG_4703.PNG';
    }
}

async function updateFooterCompanyName() {
   
    let admin_id = '1';
    const adminStr = sessionStorage.getItem('admin');
    if (adminStr) {
        try {
            const admin = JSON.parse(adminStr);
            if (admin?.id) admin_id = admin.id;
        } catch {}
    }

    const companyNameElem = document.getElementById('company-name');
    const yearElem = document.getElementById('year');
    const defaultName = 'Maski cooking Gas';

 
    if (yearElem) {
        yearElem.textContent = new Date().getFullYear();
    }

    try {
        const res = await fetch(`https://api.maskiadmin-management.com/owner_info/${admin_id}`);
        if (!res.ok) throw new Error('No owner info');
        const data = await res.json();
        if (companyNameElem) {
            companyNameElem.innerHTML = `© ${data.company_name || defaultName} <span id="year">${new Date().getFullYear()}</span>`;
        }
    } catch {
        if (companyNameElem) {
            companyNameElem.innerHTML = `© ${defaultName} <span id="year">${new Date().getFullYear()}</span>`;
        }
    }
}

